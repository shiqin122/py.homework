# 用于数据库创建的模块
import pymysql
# 基础db.Model，这样就将一个类与一张表相对应起来了

DATABASE = {
    'host': '39.101.135.150',
    'port': '3306',
    'user': 'yonghu',
    'password': 'yonghu1234',
    'database': 'test'
}

