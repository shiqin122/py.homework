import wtforms
from wtforms.validators import Length


class LoginForm(wtforms.Form):
    account = wtforms.StringField(validators=[Length(min=10, max=10,message="输入错误")])
    password = wtforms.StringField(validators=[Length(min=10, max=10, message="输入错误")])


    def validate_account(self, field):
        print(field)
        # account = field['account']
        # password = field['password']
        # 向数据库查询
        K = False
        pass
        if not not K:
            raise wtforms.ValidationError(message="账号或密码错误")


