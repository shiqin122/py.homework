from flask import Blueprint, request
from datetime import datetime
from pydantic import BaseModel,Field
import logging
from exts import Res, get_db_connection,add_1,delete_1,check_1 ,change_1

class Info(BaseModel):
    DoctorNo: str = Field(default="0",max_length=20,pattern=r'^\d+$')
    Doctorname: str = Field(default="0",max_length=20,)
    Duty: str = Field(default="0",max_length=20)
    Gender: str = Field(default="0",max_length=len("男"))
    Age: int = Field(default=0,ge=0,le=150)
    DepartmentName: str = Field(default="0",max_length=20)
    Photo: str = Field(default="0",max_length=255)


app = Blueprint('doctor', __name__, url_prefix='/doctor')
logger = logging.getLogger('doctor')
logger.setLevel(logging.INFO)

table = 'DoctorRealTable'

@app.post("/add")
def add():
    logger.warning("用户进行add存在")
    try:
        info = Info(
            Doctorname=request.json.get("Doctorname"),
            Duty=request.json.get("Duty"),
            Gender=request.json.get("Gender"),
            Age=request.json.get("Age"),
            DepartmentName=request.json.get("DepartmentName"),
            Photo=request.json.get("Photo","0")
        )
    except ValueError as e:
        return Res(status="fail",message="输入参数错误",post_examples=Info().dict()).json()
    return add_1(table, Info().dict(), info.dict()).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     return Res(status="fail",message="添加失败",post_examples=Info().dict()).json()
    #
    # return Res(status="success").json()



@app.post("/delete")
def delete():
    try:
        info = Info(
            DoctorNo=request.json.get("DoctorNo","0")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail",message="输入参数错误",post_examples=Info().dict()).json()
    return delete_1(table, "DoctorNo", info.DoctorNo).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail",message="删除失败",post_examples=Info().dict()).json()
    #
    # return Res(status="success").json()


@app.post("/check")
def check():
    try:
        info = Info(
            DoctorNo=request.json.get("DoctorNo","0"),
            Doctorname=request.json.get("Doctorname","0"),
            Duty=request.json.get("Duty","0"),
            Gender=request.json.get("Gender","0"),
            Age=request.json.get("Age",0),
            DepartmentName=request.json.get("DepartmentName","0")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail",message="输入参数错误",post_examples=Info().dict()).json()
    return check_1(table, Info().dict(), info.dict()).json()
    # data = Info()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail",message="查找失败",post_examples=Info().dict()).json()
    #
    # return Res(status="success", data={"number": 1, "data": [data.dict()]}).json()


@app.post("/change")
def change():
    try:
        info = Info(
            DoctorNo=request.json.get("DoctorNo"),
            Doctorname=request.json.get("Doctorname","0"),
            Duty=request.json.get("Duty","0"),
            Gender=request.json.get("Gender","0"),
            Age=request.json.get("Age",0),
            DepartmentName=request.json.get("DepartmentName","0"),
            Photo=request.json.get("Photo","0")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail",message="输入参数错误",post_examples=Info().dict()).json()
    return change_1(table, Info().dict(), info.dict(), 'DoctorNo', info.DoctorNo).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail",message="修改失败",post_examples=Info().dict()).json()
    #
    # return Res(status="success").json()
