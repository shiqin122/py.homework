from flask import Blueprint, request
from datetime import datetime
from pydantic import BaseModel, Field
import logging
from exts import Res, get_db_connection,add_1,delete_1,check_1 ,change_1


class Info(BaseModel):
    DGNO: str = Field(default="0", max_length=20, pattern=r'^\d+$')
    DGNAME: str = Field(default="0", max_length=20)
    DGSTOCK: int = Field(default=0, ge=0,le=150000)
    DGPRICE: float = Field(default=0, ge=0,le=150000)



app = Blueprint('drug', __name__, url_prefix='/drug')
logger = logging.getLogger('drug')
logger.setLevel(logging.INFO)

table = 'DrugRealTable'

@app.post("/add")
def add():
    logger.warning("用户进行add存在")
    try:
        info = Info(
            DGNAME=request.json.get("DGNAME", "0"),
            DGSTOCK=request.json.get("DGSTOCK", 0),
            DGPRICE=request.json.get("DGPRICE", 0)
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return add_1(table, Info().dict(), info.dict()).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="添加失败").json()
    #
    # return Res(status="success").json()


@app.post("/delete")
def delete():
    try:
        info = Info(
            DGNO=request.json.get("DGNO")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return delete_1(table, "DGNO", info.DGNO).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="删除失败").json()
    #
    # return Res(status="success").json()


@app.post("/check")
def check():
    try:
        info = Info(
            DGNO=request.json.get("DGNO", "0"),
            DGNAME=request.json.get("DGNAME", "0"),
            DGSTOCK=request.json.get("DGSTOCK", 0),
            DGPRICE=request.json.get("DGPRICE", 0)
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return check_1(table, Info().dict(), info.dict()).json()
    # data = Info()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="查找失败").json()
    #
    # return Res(status="success", data={"number": 1, "data": [data.dict()]}).json()


@app.post("/change")
def change():
    try:
        info = Info(
            DGNO=request.json.get("DGNO"),
            DGNAME=request.json.get("DGNAME", "0"),
            DGSTOCK=request.json.get("DGSTOCK", 0),
            DGPRICE=request.json.get("DGPRICE", 0)
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return change_1(table, Info().dict(), info.dict(), 'DGNO', info.DGNO).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="修改失败").json()
    #
    # return Res(status="success").json()
