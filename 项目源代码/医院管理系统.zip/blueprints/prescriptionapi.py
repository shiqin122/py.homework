from flask import Blueprint, request
from datetime import datetime
from pydantic import BaseModel, Field
import logging
from exts import Res, get_db_connection,add_1,delete_1,check_1 ,change_1


class Info(BaseModel):
    PRESCRIPTION_ID: str = Field(default="0", max_length=20, pattern=r'^\d+$')
    PatientName: str = Field(default="0", max_length=20)
    Doctorname: str = Field(default="0", max_length=20)
    DGNAME: str = Field(default="0", max_length=20)
    NUM: int = Field(default=0, ge=0,le=150000)
    PRESCRIPTION_DATE:str = Field(default="1111-11-11", max_length=20)


app = Blueprint('prescription', __name__, url_prefix='/prescription')
logger = logging.getLogger('prescription')
logger.setLevel(logging.INFO)

table = 'PrescriptionRealTable'

@app.post("/add")
def add():
    logger.warning("用户进行add存在")
    try:
        info = Info(
            PatientName=request.json.get("PNO", "0"),
            Doctorname=request.json.get("Doctorname", "0"),
            DGNAME=request.json.get("DGNAME", "0"),
            NUM=request.json.get("NUM", 0),
            PRESCRIPTION_DATE=request.json.get("PRESCRIPTION_DATE", "1111-11-11")
        )

    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return add_1(table, Info().dict(), info.dict()).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="添加失败").json()
    #
    # return Res(status="success").json()


@app.post("/delete")
def delete():
    try:
        info = Info(
            PRESCRIPTION_ID=request.json.get("PRESCRIPTION_ID", "0")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return delete_1(table, "PRESCRIPTION_ID", info.PRESCRIPTION_ID).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="删除失败").json()
    #
    # return Res(status="success").json()


@app.post("/check")
def check():
    try:
        info = Info(
            PRESCRIPTION_ID=request.json.get("PRESCRIPTION_ID", "0"),
            PatientName=request.json.get("PNO", "0"),
            Doctorname=request.json.get("Doctorname", "0"),
            DGNAME=request.json.get("DGNAME", "0"),
            NUM=request.json.get("NUM", 0),
            PRESCRIPTION_DATE=request.json.get("PRESCRIPTION_DATE", "1111-11-11")
        )

    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return check_1(table, Info().dict(), info.dict()).json()
    # data = Info()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="查找失败").json()
    #
    # return Res(status="success", data={"number": 1, "data": [data.dict()]}).json()


@app.post("/change")
def change():
    try:
        info = Info(
            PRESCRIPTION_ID=request.json.get("PRESCRIPTION_ID"),
            PatientName=request.json.get("PNO", "0"),
            Doctorname=request.json.get("Doctorname", "0"),
            DGNAME=request.json.get("DGNAME", "0"),
            NUM=request.json.get("NUM", 0),
            PRESCRIPTION_DATE=request.json.get("PRESCRIPTION_DATE", "1111-11-11")
        )

    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return change_1(table, Info().dict(), info.dict(), 'PRESCRIPTION_ID', info.PRESCRIPTION_ID).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="修改失败").json()
    #
    # return Res(status="success").json()
