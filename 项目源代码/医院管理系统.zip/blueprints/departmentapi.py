from flask import Blueprint, request,current_app
from datetime import datetime
from pydantic import BaseModel, Field
import logging
from exts import Res, get_db_connection,add_1,delete_1,check_1 ,change_1


class Info(BaseModel):
    DPNAME: str = Field(default="0", max_length=20)
    DPNO: str = Field(default="0", max_length=20, pattern=r'^\d+$')
    DPTEL: str = Field(default="12345678910", min_length=11, max_length=11, pattern=r'^\d+$')


app = Blueprint('department', __name__, url_prefix='/department')
logger = logging.getLogger('department')
logger.setLevel(logging.INFO)

table = 'DepartmentRealTable'

@app.post("/add")
def add():
    logger.warning("用户进行add存在")
    try:
        info = Info(
            DPNAME=request.json.get("DPNAME"),
            DPTEL=request.json.get("DPTEL")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()

    return add_1(table,Info().dict(),info.dict()).json()
    # try:
    #     with get_db_connection() as connection:
    #         with connection.cursor() as cursor:
    #             sql = "INSERT INTO DepartmentRealTable (DPNAME, DPTEL) VALUES (%s, %s)"
    #             cursor.execute(sql, (info.DPNAME, info.DPTEL))
    #             rows_affected = cursor.rowcount
    #
    #             if rows_affected == 0:
    #                 app.logger.warning("账号：", info.account, "密码：", info.password, "输入参数错误，登入失败")
    #                 return Res(status="fail", message="账号或密码错误", post_examples=Info().dict()).json()
    #             else:
    #                 connection.commit()
    # except OperationalError as e:
    #     print(e)
    #     return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()
    # except ProgrammingError as e:
    #     print(e)
    #     return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()
    # # logger.warning("账号：", info.account, "密码：", info.password, "输入参数错误，登入失败")
    # return Res(status="success").json()


@app.post("/delete")
def delete():
    # app.logger.warning("用户进行delete存在")
    try:
        info = Info(
            DPNO=request.json.get("DPNO")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()

    return delete_1(table, "DPNO", info.DPNO).json()




@app.post("/check")
def check():
    logger.warning("用户进行check存在")
    try:
        info = Info(
            DPNAME=request.json.get("DPNAME", "0"),
            DPNO=request.json.get("DPNO","0"),
            DPTEL=request.json.get("DPTEL", "12345678910")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()

    return check_1(table,Info().dict(),info.dict()).json()
    # try:
    #     with get_db_connection() as connection:
    #         with connection.cursor() as cursor:
    #             sql = "SELECT DPNO, DPNAME, DPTEL FROM `DepartmentRealTable` WHERE 1=1"
    #             sql_data = []
    #             if info.DPNAME != "0":
    #                 sql += " AND DPNAME=%s"
    #                 sql_data.append(info.DPNAME)
    #             if info.DPNO != "0":
    #                 sql += " AND DPNO=%s"
    #                 sql_data.append(info.DPNO)
    #             if info.DPTEL != "12345678910":
    #                 sql += " AND DPTEL=%s"
    #                 sql_data.append(info.DPTEL)
    #
    #             if len(sql_data) == 0:
    #                 return Res(status="success", data={"number": 0, "data": []}).json()
    #
    #             cursor.execute(sql, tuple(sql_data))
    #             items = cursor.fetchall()
    #
    #             if len(items) == 0:
    #                 return Res(status="success", data={"number": 0, "data": []}).json()
    #
    #             data = [
    #                 {
    #                     "DPNAME": item[0],
    #                     "DPNO":item[1],
    #                     "DPTEL":item[2]
    #                 }
    #                 for item in items
    #             ]
    #
    #             return Res(status="success", data={"number": len(data), "data": data}).json()
    # except OperationalError as e:
    #     print(e)
    #     return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()
    # except ProgrammingError as e:
    #     print(e)
    #     return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()
    # return Res(status="success").json()


@app.post("/change")
def change():
    logger.warning("用户进行change存在")
    try:
        info = Info(
            DPNAME=request.json.get("DPNAME", "0"),
            DPNO=request.json.get("DPNO"),
            DPTEL=request.json.get("DPTEL", "12345678910")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()


    return change_1(table, Info().dict(),info.dict(),'DPNO',info.DPNO).json()
    # try:
    #     with get_db_connection() as connection:
    #         with connection.cursor() as cursor:
    #             sql = "UPDATE `DepartmentRealTable` SET DPNAME='', DPTEL='' WHERE DPNO=%s"
    #             sql_data = []
    #             if info.DPNAME != "0":
    #                 sql += " AND DPNAME=%s"
    #                 sql_data.append(info.DPNAME)
    #             if info.DPTEL != "12345678910":
    #                 sql += " AND DPTEL=%s"
    #                 sql_data.append(info.DPTEL)
    #
    #             if len(sql_data) == 0:
    #                 return Res(status="success", data={"number": 0, "data": []}).json()
    #             sql_data.append(info.DPNO)
    #             cursor.execute(sql, tuple(sql_data))
    #             items = cursor.fetchall()
    #
    #             if len(items) == 0:
    #                 return Res(status="success", data={"number": 0, "data": []}).json()
    #
    #             data = [
    #                 {
    #                     "DPNAME": item[0],
    #                     "DPNO":item[1],
    #                     "DPTEL":item[2]
    #                 }
    #                 for item in items
    #             ]
    #
    #             return Res(status="success", data={"number": len(data), "data": data}).json()
    # except OperationalError as e:
    #     print(e)
    #     return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()
    # except ProgrammingError as e:
    #     print(e)
    #     return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()
    # return Res(status="success").json()
    # try:
    #     info = Info(
    #         DPNAME=request.form.get("DPNAME", "0"),
    #         DPNO=request.form.get("DPNO"),
    #         DPTEL=request.form.get("DPTEL", "12345678910")
    #     )
    # except ValueError as e:
    #     print(e)
    #     return Res(status="fail", message="输入参数错误").json()
    #
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="未找到指定目标").json()
    #
    # return Res(status="success").json()