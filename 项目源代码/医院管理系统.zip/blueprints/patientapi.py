from flask import Blueprint, request
from datetime import datetime
from pydantic import BaseModel, Field
import logging
from exts import Res, get_db_connection,add_1,delete_1,check_1 ,change_1



class Info(BaseModel):
    PatientNo: str = Field(default="0", max_length=20, pattern=r'^\d+$')
    PatientName: str = Field(default="0", max_length=20)
    Gender: str = Field(default="0", max_length=len("男"))
    Age: int = Field(default=0, ge=0, le=150)
    DoctorName: str = Field(default="0", max_length=20)
    Conditions: str = Field(default="0", max_length=20)
    Balance: float = Field(default=0, ge=0, le=150000)


app = Blueprint('patient', __name__, url_prefix='/patient')
logger = logging.getLogger('patient')
logger.setLevel(logging.INFO)

table = 'PatientRealTable'

@app.post("/add")
def add():
    logger.warning("用户进行add存在")
    try:
        info = Info(
            PatientName=request.json.get("PatientName", "0"),
            Gender=request.json.get("Gender", "0"),
            Age=request.json.get("Age", 0),
            DoctorName=request.json.get("DoctorName", "0"),
            Conditions=request.json.get("Condition", "0"),
            Balance=request.json.get("Balance", 0)
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return add_1(table, Info().dict(), info.dict()).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="添加失败").json()
    #
    # return Res(status="success").json()


@app.post("/delete")
def delete():
    try:
        info = Info(
            PatientNo=request.json.get("PatientNo")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return delete_1(table, "PatientNo", info.PatientNo).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="删除失败").json()
    #
    # return Res(status="success").json()


@app.post("/check")
def check():
    try:
        info = Info(
            PatientNo=request.json.get("PatientNo", "0"),
            PatientName=request.json.get("PatientName", "0"),
            Gender=request.json.get("Gender", "0"),
            Age=request.json.get("Age", 0),
            DoctorName=request.json.get("DoctorName", "0"),
            Condition=request.json.get("Condition", "0"),
            Balance=request.json.get("Balance", 0)
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return check_1(table, Info().dict(), info.dict()).json()
    # data = Info()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="查找失败").json()
    #
    # return Res(status="success", data={"number": 1, "data": [data.dict()]}).json()


@app.post("/change")
def change():
    try:
        info = Info(
            PatientNo=request.json.get("PatientNo"),
            PatientName=request.json.get("PatientName", "0"),
            Gender=request.json.get("Gender", "0"),
            Age=request.json.get("Age", 0),
            DoctorName=request.json.get("DoctorName", "0"),
            Condition=request.json.get("Condition", "0"),
            Balance=request.json.get("Balance", 0)
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return change_1(table, Info().dict(), info.dict(), 'PatientNo', info.PatientNo).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="修改失败").json()
    #
    # return Res(status="success").json()
