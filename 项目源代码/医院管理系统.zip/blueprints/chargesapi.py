import logging

from flask import Blueprint, request
from pydantic import BaseModel, Field

from exts import Res, add_1, delete_1, check_1, change_1


class Info(BaseModel):
    charges_id: str = Field(default="0", max_length=20, pattern=r'^\d+$')
    charges: float = Field(default=0, ge=0, le=150000)
    charges_date: str = Field(default="1111-11-11", max_length=20)


app = Blueprint('charges', __name__, url_prefix='/charges')
logger = logging.getLogger('charges')
logger.setLevel(logging.INFO)

table = 'ChargesTable'


@app.post("/add")
def add():
    logger.warning("用户进行add存在")
    try:
        info = Info(
            charges=request.json.get("charges", "0"),
            charges_date=request.json.get("charges_date", "1111-11-11")
        )

    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return add_1(table, Info().dict(), info.dict()).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="添加失败").json()
    #
    # return Res(status="success").json()


@app.post("/delete")
def delete():
    try:
        info = Info(
            charges_id=request.json.get("charges_id", "0")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return delete_1(table, "charges_id", info.charges_id).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="删除失败").json()
    #
    # return Res(status="success").json()


@app.post("/check")
def check():
    try:
        info = Info(
            charges_id=request.json.get("charges_id", "0"),
            charges=request.json.get("charges", "0"),
            charges_date=request.json.get("charges_date", "1111-11-11")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return check_1(table, Info().dict(), info.dict()).json()
    # data = Info()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="查找失败").json()
    #
    # return Res(status="success", data={"number": 1, "data": [data.dict()]}).json()


@app.post("/change")
def change():
    try:
        info = Info(
            charges_id=request.json.get("charges_id"),
            charges=request.json.get("charges", "0"),
            charges_date=request.json.get("charges_date", "1111-11-11")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误").json()
    return change_1(table, Info().dict(), info.dict(), 'charges_id', info.charges_id).json()
    # try:
    #     # -------往数据库里面查询账号密码----------
    #     pass
    #     # ------------------------------------
    # except Exception as e:
    #     print(e)
    #     return Res(status="fail", message="修改失败").json()
    #
    # return Res(status="success").json()
