# 主要代码文件

import logging
import string
from random import choices  # 用于cookie增加随机性

# flask的工具
from flask import Flask, request
from flask_cors import CORS
from flask_login import LoginManager
# 辅助flask的工具
from pydantic import BaseModel, Field  # 数据限制
from pymysql.err import OperationalError, ProgrammingError

from blueprints.chargesapi import app as charges_app
from blueprints.departmentapi import app as department_app
# 蓝图
from blueprints.doctorapi import app as doctor_app
from blueprints.drugapi import app as drug_app
from blueprints.patientapi import app as patient_app
from blueprints.prescriptionapi import app as prescription_app
# 自己的包
from exts import init_logging, LOGGING_CONFIG, Res, get_db_connection

# flask的初始化
app = Flask(__name__)

# 解决跨域问题
CORS(app)

# 设置log文件
init_logging(app, LOGGING_CONFIG)
logger = logging.getLogger(__name__)

# 导入配置文件
# app.config.from_object(config)
app.config['SECRET_KEY'] = "a@sda3232123ksa"
# init_logging()

# 导入蓝图界面
app.register_blueprint(doctor_app)
app.register_blueprint(department_app)
app.register_blueprint(drug_app)
app.register_blueprint(patient_app)
app.register_blueprint(prescription_app)
app.register_blueprint(charges_app)

# 导入快速退出登入的模块
# login_manager = LoginManager(app)


class Info(BaseModel):
    account: str = Field(default="01234567", min_length=8, max_length=8, pattern=r'^\d+$')
    password: str = Field(default="0001", max_length=20, pattern=r'^\d+$')


class User(BaseModel):
    id: int = None
    account: str = None
    password: str = None
    cookie: str = None


def generate_cookie_value(length=18):
    # 定义可能的字符集：大写字母、小写字母和数字
    characters = string.ascii_letters + string.digits
    # 使用random.choices从字符集中随机选择指定长度的字符
    cookie_value = ''.join(choices(characters, k=length))
    return cookie_value


@app.before_request
def check_user_authenticated():
    if request.method == 'POST' and request.content_type == 'application/json':
        if request.endpoint not in ['login_view']:
            cookie = request.json.get("cookie")
            try:
                with get_db_connection() as connection:
                    with connection.cursor() as cursor:
                        sql = "SELECT *  from users where cookie=%s"
                        cursor.execute(sql, (cookie,))
                        item = cursor.fetchall()

                        if len(item) != 1:
                            app.logger.warning('为查找到，未登入')
                            return Res(status="nologin", message="未登入！").json()
            except OperationalError as e:
                print(e)
                return Res(status="nologin", message="未登入！").json()
            app.logger.warning(cookie + '+已成功登入')
    else:
        app.logger.warning('非post请求，未登入')
        return Res(status="nologin", message="未登入！").json()

    # if request.endpoint not in ['login_view'] and 'user_id' not in session:
    #     return Res(status="nologin", message="未登入！").json()


@app.route('/login', methods=['POST'], endpoint='login_view')
def login():
    try:
        info = Info(
            account=request.json.get("account"),
            password=request.json.get("password")
        )
    except ValueError as e:
        print(e)
        return Res(status="fail", message="输入参数错误", post_examples=Info().dict()).json()

    # -------往数据库里面查询账号密码----------
    try:
        with get_db_connection() as connection:
            with connection.cursor() as cursor:
                sql = "UPDATE users SET cookie = %s where username=%s and password=%s"
                cookie = generate_cookie_value()
                cursor.execute(sql, (cookie, info.account, info.password))
                rows_affected = cursor.rowcount

            if rows_affected == 0:
                app.logger.warning("账号：" + info.account + "密码："+info.password + "输入参数错误，登入失败")
                return Res(status="fail", message="账号或密码错误", post_examples=Info().dict()).json()
            else:
                connection.commit()
            # session['user_id'] = str(item[0]) + info.account
    except OperationalError as e:
        print(e)
        return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()

    # user = User(id=1, account="01234567", password="12345")
    # if info.account != user.account or info.password != user.password:
    #     return Res(status="fail", message="账号或密码错误", post_examples=Info().dict()).json()
    #
    # # ------------------------------------
    #
    #
    # user.cookie = session['user_id']
    app.logger.warning("账号："+ info.account+ "密码："+info.password+ "登入成功")

    return Res(status="success", message=cookie).json()


@app.route('/logout', methods=['POST'])
def logout():
    # logout_user()  # 使用Flask-Login的logout_user函数
    # session.clear()
    cookie = request.json.get("cookie")
    try:
        with get_db_connection() as connection:
            with connection.cursor() as cursor:
                sql = "UPDATE users SET cookie = NULL where cookie=%s"
                cursor.execute(sql, (cookie,))
                rows_affected = cursor.rowcount

            if rows_affected == 0:
                app.logger.warning("cookie："+cookie + "未查到到，退出失败")
                return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()
            else:
                connection.commit()
            # session['user_id'] = str(item[0]) + info.account
    except OperationalError as e:
        print(e)
        return Res(status="fail", message="系统错误", post_examples=Info().dict()).json()
    app.logger.warning("cookie："+ cookie+ "退出成功")
    return Res(status="success").json()


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
