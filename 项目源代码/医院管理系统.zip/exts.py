# 用于初始数据和其他配置，尤其是为了解决循环导入的问题
# flask-sqlalchemy
import logging.config

import pymysql
from pydantic import BaseModel  # 数据限制
from pymysql.err import OperationalError, ProgrammingError, IntegrityError


class Res(BaseModel):
    status: str = None
    message: str = None
    data: dict = None


# 初始化日志配置
DB_HOST = '39.101.135.150'
DB_USER = 'yonghu'
DB_PASS = 'yonghu1234'  # 请替换为你的密码
DB_NAME = 'hospital'  # 请替换为你的数据库名


def get_db_connection():
    return pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASS, db=DB_NAME, charset='utf8mb4')


def add_1(table: str, exdatas: dict, datas: dict):
    try:
        with get_db_connection() as connection:
            with connection.cursor() as cursor:

                sql_p = f"INSERT INTO {table} ("
                sql_q = " VALUES ("
                sql_data = []
                for key, value in datas.items():
                    if exdatas[key] != value:
                        sql_p += str(key) + ','
                        sql_q += "%s" + ','
                        sql_data.append(value)

                sql = sql_p[:-1] + ') ' + sql_q[:-1] + ')'
                print(sql)
                print(sql_data)
                if len(sql_data) == 0:
                    return Res(status="fail", message="参数有问题")

                cursor.execute(sql, tuple(sql_data))
                rows_affected = cursor.rowcount

                if rows_affected == 0:
                    return Res(status="fail", message="数据库操作失败")
                else:
                    connection.commit()
    except OperationalError as e:
        print(e)
        return Res(status="fail", message="数据库连接失败")
    except ProgrammingError as e:
        print(e)
        return Res(status="fail", message="数据库操作失败")
    except IntegrityError as e:
        print(e)
        return Res(status="fail", message="数据库操作失败")
    return Res(status="success")


def delete_1(table: str, name: str, ID: str):
    try:
        with get_db_connection() as connection:
            with connection.cursor() as cursor:
                sql = f"DELETE FROM {table} WHERE {name}=%s"
                cursor.execute(sql, (ID,))
                rows_affected = cursor.rowcount
                print(sql)
                print(ID)
                if rows_affected == 0:
                    return Res(status="fail", message="没有找到需要删除的对象")

                connection.commit()
    except OperationalError as e:
        print(e)
        return Res(status="fail", message="数据库连接失败")
    except ProgrammingError as e:
        print(e)
        return Res(status="fail", message="数据库操作失败")
    except IntegrityError as e:
        print(e)
        return Res(status="fail", message="数据库操作失败")
    return Res(status="success")


def check_1(table: str, exdatas: dict, datas: dict):
    try:
        with get_db_connection() as connection:
            with connection.cursor() as cursor:

                sql_p = "SELECT "
                sql_q = f" FROM {table} WHERE 1=1 "
                sql_data = []
                names = []
                for key, value in datas.items():
                    if exdatas[key] != value:
                        sql_q += " AND " + str(key) + "=%s"
                        sql_data.append(value)
                    sql_p += str(key) + ','
                    names.append(str(key))

                sql = sql_p[:-1] + sql_q
                print(sql)
                print(sql_data)

                # sql = "SELECT DPNO, DPNAME, DPTEL FROM `DepartmentRealTable` WHERE 1=1"
                # sql_data = []
                # if info.DPNAME != "0":
                #     sql += " AND DPNAME=%s"
                #     sql_data.append(info.DPNAME)
                # if info.DPNO != "0":
                #     sql += " AND DPNO=%s"
                #     sql_data.append(info.DPNO)
                # if info.DPTEL != "12345678910":
                #     sql += " AND DPTEL=%s"
                #     sql_data.append(info.DPTEL)

                if len(sql_data) == 0:
                    return Res(status="success", data={"number": 0, "data": []})

                cursor.execute(sql, tuple(sql_data))
                items = cursor.fetchall()

                data = [
                    dict(zip(names, item))
                    for item in items if len(item) == len(names)
                ]

    except OperationalError as e:
        print(e)
        return Res(status="fail", message="数据库连接失败")
    except ProgrammingError as e:
        print(e)
        return Res(status="fail", message="数据库操作失败")
    except IntegrityError as e:
        print(e)
        return Res(status="fail", message="添加已经存在的对象")

    return Res(status="success", data={"number": len(data), "data": data})


def change_1(table: str, exdatas: dict, datas: dict, name: str, ID: str):
    try:
        with get_db_connection() as connection:
            with connection.cursor() as cursor:

                sql_p = f"UPDATE {table} SET "
                sql_q = f" WHERE {name}=%s"
                sql_data = []

                for key, value in datas.items():
                    if exdatas[key] != value and key!= name:
                        sql_p += str(key) + "=%s,"
                        sql_data.append(value)

                sql = sql_p[:-1] + sql_q
                print(sql)
                print(sql_data)

                if len(sql_data) == 0:
                    return Res(status="fail", message="参数有问题")
                sql_data.append(ID)

                cursor.execute(sql, tuple(sql_data))
                rows_affected = cursor.rowcount

                if rows_affected == 0:
                    return Res(status="fail", message="数据库操作失败")
                else:
                    connection.commit()

                # sql = "UPDATE `DepartmentRealTable` SET DPNAME='', DPTEL='' WHERE DPNO=%s"
                # sql_data = []
                # if info.DPNAME != "0":
                #     sql += " AND DPNAME=%s"
                #     sql_data.append(info.DPNAME)
                # if info.DPTEL != "12345678910":
                #     sql += " AND DPTEL=%s"
                #     sql_data.append(info.DPTEL)
                #
                # if len(sql_data) == 0:
                #     return Res(status="success", data={"number": 0, "data": []}).json()
                # sql_data.append(info.DPNO)
                # cursor.execute(sql, tuple(sql_data))
                # items = cursor.fetchall()
                #
                # if len(items) == 0:
                #     return Res(status="success", data={"number": 0, "data": []}).json()
                #
                # data = [
                #     {
                #         "DPNAME": item[0],
                #         "DPNO": item[1],
                #         "DPTEL": item[2]
                #     }
                #     for item in items
                # ]
                #
                # return Res(status="success", data={"number": len(data), "data": data}).json()
    except OperationalError as e:
        print(e)
        return Res(status="fail", message="数据库连接失败")
    except ProgrammingError as e:
        print(e)
        return Res(status="fail", message="数据库操作失败")
    except IntegrityError as e:
        print(e)
        return Res(status="fail", message="添加已经存在的对象")

    return Res(status="success")


# 假设的日志配置字典
LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(asctime)s %(levelname)s %(message)s '
                      '(%(process)d)%(processName)s '
                      '[%(threadName)s] %(name)s %(filename)s:%(lineno)d'
        },
    },
    'handlers': {
        'file': {
            'level': 'INFO',
            'class': 'logging.FileHandler',
            'filename': 'app.log',
            'formatter': 'verbose'
        },
    },
    'loggers': {
        'your_app_name': {  # 替换为你的 Flask 应用名
            'handlers': ['file'],
            'level': 'INFO',
            'propagate': True
        },
        'your_blueprint_name': {  # 替换为你的蓝图名
            'handlers': ['file'],
            'level': 'INFO',
            'propagate': False  # 设置为 False 避免重复日志
        },
    },
    'root': {
        'handlers': [],  # 根记录器不处理任何日志
        'level': 'WARNING',  # 设置根记录器的日志级别
    },
}


# 初始化日志配置的函数
def init_logging(app, logging_config=LOGGING_CONFIG):
    # 设置 Flask 应用日志记录器的名称
    app.logger.name = 'your_app_name'  # 替换为你的 Flask 应用名
    # 使用字典配置配置日志
    logging.config.dictConfig(logging_config)

# 无需其他代码，这个模块仅包含配置和初始化函数
# logger.setLevel(level=logging.INFO)
# handler = logging.FileHandler("log.txt")
# handler.setLevel(logging.INFO)
# formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# handler.setFormatter(formatter)
# logger.addHandler(handler)

# logger.info("Start print log")
# logger.debug("Do something")
# logger.warning("Something maybe fail.")
# logger.info("Finish")
